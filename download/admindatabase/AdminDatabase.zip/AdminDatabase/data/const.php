<?php

class Constants {

    const PROJECT_NAME = 'ADMIN DATABASE';
    const AUTHOR = '2017 © Somov Studio';
    
    const EVENT_ADD = 'add';
    const EVENT_EDIT = 'edit';
    const EVENT_UPDATE = 'update';
    const EVENT_REMOVE = 'remove';
    const EVENT_SEARCH = 'search';
    const EVENT_TARGET = 'target';
    
}
