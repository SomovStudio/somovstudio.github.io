<?php

class Config {
    /* SERVER AND DATABASE */

    public static $Server = "localhost";
    public static $DatabaseMain = "demoDB";
    public static $DatabaseUser = 'demoDB';
    public static $TableUsers = 'users';

    /* ROOT USER */
    public static $RootUserName = 'root';
    public static $RootUserPass = '';

}
