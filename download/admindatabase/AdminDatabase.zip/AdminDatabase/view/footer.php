<div class="Clear"></div>
<div id="footer">
    <div id="footer_title"><br><?php echo Constants::AUTHOR ?></div>	
</div>