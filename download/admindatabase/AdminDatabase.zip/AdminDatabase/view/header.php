<div id="header">
    <div id="header_title_logo"><br><br><h2><?php echo Constants::PROJECT_NAME ?></h2></div>
    <div id="header_info">
        USER INFORMATION:
        <br><label>Login: <?php echo $_SESSION['login'] ?></label>
        <br><label>Date: <?php echo date('l jS \of F Y h:i:s A') ?></label>
    </div>
</div>