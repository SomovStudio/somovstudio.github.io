# Hat

Браузер со встроенной технологией автоматизации тестирования Web приложений.

[MIT License] https://mit-license.org/

Особенность браузера Hat в том что автотесты напрямую выполняются в браузере без Selenium и WebDriver.

Встроенный фреймворк HatFramework содержит достаточное количество методов необходимых для выполнения основных задач автоматизации тестирования.
Для описания скриптов автотестов используется язык программирования C# и встроенный редактор кода. Так же в качестве редактора можно воспользоваться Visual Studio.
Удобный интерфейс браузера отображает все шаги выполнения теста с подробным описанием событий. 
Результат проверки формируется в отчет и отправляются на указаную почту. 
Запуск автотестов возможен из командной строки операционной системы Windows это пригодится при использовании автотестов в популярных средствах непрерывной интеграции таких как: Jenkins, TeamCity, GitLab CI/CD.

[Download] https://github.com/SomovStudio/Hat/releases
[Download] https://gitflic.ru/project/somovstudio/hat/release


-------------------------------------------------------

Системные требования:
	1. Операционная система Windows 8, 8.1, 10, 11

	2. Microsoft .NET Framework 4.8
		Скачать .NET Framework Runtime по ссылке: https://dotnet.microsoft.com/en-us/download/dotnet-framework/net48

	3. Microsoft Edge WebView2
		Скачать WebView2 Runtime по ссылке: https://developer.microsoft.com/en-us/microsoft-edge/webview2/

-------------------------------------------------------

[Официальный сайт] https://somovstudio.github.io/hat.html
[Документация online]  https://somovstudio.github.io/help/Hat/index.html
[Документация offline] https://gitflic.ru/project/somovstudio/hat/blob?file=Help%2Fhelp.chm&branch=master
[Видео обзор]: https://youtu.be/Dn9UtrNj6EM

-------------------------------------------------------

Программа разработана при некоммерческой поддержке компании "Зионек" https://zionec.ru/
Компания "Зионек" занимается разработкой "Интернет-магазинов", "Корпоративных порталов", "CRM-систем" и собственных решений.